// Array of inspirational quotes by or about Maya Angelou
const quotes = [
    "If you don't like something, change it. If you can't change it, change your attitude.",
    "We may encounter many defeats but we must not be defeated.",
    "You may not control all the events that happen to you, but you can decide not to be reduced by them.",
    "I've learned that people will forget what you said, people will forget what you did, but people will never forget how you made them feel.",
    "There is no greater agony than bearing an untold story inside you.",
    "Try to be a rainbow in someone's cloud."
];

// Function to display a random quote
function displayRandomQuote() {
    const quoteElement = document.getElementById('quote');
    const randomIndex = Math.floor(Math.random() * quotes.length);
    quoteElement.textContent = quotes[randomIndex];
}

// Function to toggle dark mode
function toggleDarkMode() {
    document.body.classList.toggle('dark-mode');
}

// Add event listeners for buttons
document.getElementById('quoteButton').addEventListener('click', displayRandomQuote);
document.getElementById('darkModeToggle').addEventListener('click', toggleDarkMode);

// Smooth scrolling functionality for navigation links (if added)
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});