// Get modal element
const modal = document.getElementById('modal');
// Get open modal button
const openModalButton = document.getElementById('open-modal');
// Get close button
const closeModalButton = document.getElementById('close-modal');

// Open modal when button is clicked
openModalButton.addEventListener('click', () => {
    modal.style.display = 'block';
});

// Close modal when "X" is clicked
closeModalButton.addEventListener('click', () => {
    modal.style.display = 'none';
});

// Close modal when clicking outside of the modal content
window.addEventListener('click', (event) => {
    if (event.target == modal) {
        modal.style.display = 'none';
    }
});