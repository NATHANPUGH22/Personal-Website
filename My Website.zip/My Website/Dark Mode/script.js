const toggleButton = document.getElementById('toggle-button');
const body = document.body;
const container = document.querySelector('.container');

toggleButton.addEventListener('click', function() {
    body.classList.toggle('dark-mode');
    container.classList.toggle('dark-mode');
    
    if (body.classList.contains('dark-mode')) {
        toggleButton.textContent = 'Switch to Light Mode';
    } else {
        toggleButton.textContent = 'Switch to Dark Mode';
    }
});