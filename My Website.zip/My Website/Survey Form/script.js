document.getElementById('survey-form').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevents the default form submission

    // Collecting the form data
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const rating = document.getElementById('rating').value;
    const comments = document.getElementById('comments').value;

    // Display a thank you message
    const thankYouMessage = document.getElementById('thank-you-message');
    thankYouMessage.textContent = `Thank you ${name}! for participating in our survey! Your response has been recorded. This brief questionnaire is designed to gather your opinions and feelings about French Bulldogs (commonly known as Frenchies).

Frenchies have gained immense popularity in recent years, known for their charming personalities and distinctive looks. I want to hear from you about your experiences, preferences, and any unique insights you might have regarding this adorable breed.

Your feedback will help me understand the public perception of Frenchies better.

Thank you for sharing your thoughts with me!`;
    thankYouMessage.classList.remove('hidden');

    // Reset the form
    document.getElementById('survey-form').reset();
});
